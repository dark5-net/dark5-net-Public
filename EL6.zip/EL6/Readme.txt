有条件的话建议先安装Telnet Server，这样在中断后可以执行ssh启动命令。
当然如果可以连到终端是再好不过了

#1、安装前备份
cp /etc/pam.d/sshd /etc/pam.d/sshd.bak
#最好是将原openssh卸载掉
yum remove openssh*
#2、安装下载的文件
rpm -ihv *.rpm
rpm -Uvh *.rpm --nodeps --force
#3、修改配置文件
echo "UsePAM yes" >> /etc/ssh/sshd_config
echo "PermitRootLogin yes" >> /etc/ssh/sshd_config
#4、还原之前备份文件
rm -rf /etc/pam.d/sshd
cp /etc/pam.d/sshd.bak /etc/pam.d/sshd
#5、启动服务
chmod 400 /etc/ssh/ssh_host_ecdsa_key /etc/ssh/ssh_host_ed25519_key /etc/ssh/ssh_host_rsa_key  #如已卸载掉则不执行此条
service sshd restart
重启会导致连接中断，需要服务器中执行
service sshd start

[root@localhost ~]# cat /etc/redhat-release 
CentOS release 6.8 (Final)
[root@localhost ~]# uname -a
Linux localhost 2.6.32-642.el6.x86_64 #1 SMP Tue May 10 17:27:01 UTC 2016 x86_64 x86_64 x86_64 GNU/Linux
